package com.k.ultimatetg

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object TelegramApi {
    private const val BASE = "https://api.telegram.org/bot"
    val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()

    fun getUpdates(token: String, offset: Long): JSONObject? = try {
        val req = Request.Builder()
            .url("$BASE$token/getUpdates?timeout=50&offset=$offset")
            .build()
        http.newCall(req).execute().use { r ->
            if (r.isSuccessful) JSONObject(r.body!!.string()) else null
        }
    } catch (_: Exception) { null }

    fun sendMessage(token: String, chat: Long, text: String, markup: String? = null): Boolean = try {
        val form = okhttp3.FormBody.Builder()
            .add("chat_id", chat.toString())
            .add("text", text)
            .add("parse_mode", "HTML")
        markup?.let { form.add("reply_markup", it) }
        val req = Request.Builder().url("${BASE}$token/sendMessage").post(form.build()).build()
        http.newCall(req).execute().use { it.isSuccessful }
    } catch (_: Exception) { false }

    fun sendPhoto(token: String, chat: Long, file: File, caption: String = ""): Boolean =
        sendMedia(token, chat, file, "photo", "image/*", caption)

    fun sendVideo(token: String, chat: Long, file: File, caption: String = ""): Boolean =
        sendMedia(token, chat, file, "video", "video/mp4", caption)

    fun sendDocument(token: String, chat: Long, file: File, caption: String = ""): Boolean =
        sendMedia(token, chat, file, "document", "application/octet-stream", caption)

    private fun sendMedia(token: String, chat: Long, file: File,
                          type: String, mime: String, caption: String): Boolean = try {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chat.toString())
            .addFormDataPart("caption", caption)
            .addFormDataPart(type, file.name, file.asRequestBody(mime.toMediaTypeOrNull()))
            .build()
        val req = Request.Builder().url("${BASE}$token/send${type.replaceFirstChar { it.uppercase() }}")
            .post(body).build()
        http.newCall(req).execute().use { it.isSuccessful }
    } catch (_: Exception) { false }
}