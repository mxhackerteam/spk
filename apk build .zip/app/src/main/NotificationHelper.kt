package com.k.ultimatetg

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.os.Build

object NotificationHelper {
    const val CHANNEL = "svc_ch"
    const val ID = 0x404

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(CHANNEL, "Service",
                NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false); enableLights(false); enableVibration(false)
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
            nm.createNotificationChannel(ch)
        }
    }

    fun build(ctx: Context): Notification {
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(ctx, CHANNEL) else Notification.Builder(ctx)
        return b.setContentTitle("").setContentText("")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true).setPriority(Notification.PRIORITY_MIN)
            .setVisibility(Notification.VISIBILITY_SECRET).build()
    }

    fun hideAfterStart(ctx: Context, svc: Service) {
        try {
            svc.startForeground(ID, build(ctx))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.getSystemService(NotificationManager::class.java).cancel(ID)
            }
        } catch (_: Exception) {}
    }
}