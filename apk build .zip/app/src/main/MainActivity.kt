package com.k.ultimatetg

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val tokenInput = EditText(this).apply {
            hint = "Bot token"
            setText(Prefs.token)
        }
        val chatInput = EditText(this).apply {
            hint = "Chat ID"
            if (Prefs.chatId != 0L) setText(Prefs.chatId.toString())
        }
        val saveBtn = Button(this).apply { text = "Save + Start" }
        val stopBtn = Button(this).apply { text = "Stop Service" }

        root.addView(tokenInput)
        root.addView(chatInput)
        root.addView(saveBtn)
        root.addView(stopBtn)
        setContentView(root)

        requestPerms()

        saveBtn.setOnClickListener {
            val t = tokenInput.text.toString().trim()
            val c = chatInput.text.toString().trim().toLongOrNull() ?: 0L
            if (t.isEmpty() || c == 0L) {
                Toast.makeText(this, "Need token + chat", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.token = t
            Prefs.chatId = c
            TelegramApi.sendMessage(t, c, "✅ <b>Connected.</b>\nCommands:\n/gallery\n/folders\n/download &lt;folder&gt;")
            val i = Intent(this, BotService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                startForegroundService(i) else startService(i)
            Toast.makeText(this, "Started", Toast.LENGTH_SHORT).show()
            finish()
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, BotService::class.java))
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestPerms() {
        val perms = mutableListOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.POST_NOTIFICATIONS
        )
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.READ_MEDIA_IMAGES
            perms += Manifest.permission.READ_MEDIA_VIDEO
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty())
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)

        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            } catch (_: Exception) {}
        }
    }
}