package com.k.ultimatetg

import android.content.Context

object Prefs {
    private const val F = "cfg"
    private const val K_TOKEN = "token"
    private const val K_CHAT = "chat"
    private const val K_OFFSET = "offset"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(F, Context.MODE_PRIVATE)

    var token: String
        get() = sp(appCtx).getString(K_TOKEN, "") ?: ""
        set(v) { sp(appCtx).edit().putString(K_TOKEN, v).apply() }

    var chatId: Long
        get() = sp(appCtx).getLong(K_CHAT, 0L)
        set(v) { sp(appCtx).edit().putLong(K_CHAT, v).apply() }

    var offset: Long
        get() = sp(appCtx).getLong(K_OFFSET, 0L)
        set(v) { sp(appCtx).edit().putLong(K_OFFSET, v).apply() }

    lateinit var appCtx: Context
    fun init(ctx: Context) { appCtx = ctx.applicationContext }
}