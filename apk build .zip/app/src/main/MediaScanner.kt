package com.k.ultimatetg

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

data class MediaItem(val path: String, val name: String,
                     val size: Long, val date: Long, val isVideo: Boolean)

object MediaScanner {
    private val seen = CopyOnWriteArrayList<String>()

    fun scan(ctx: Context, onlyNew: Boolean = false): List<MediaItem> {
        val all = ArrayList<MediaItem>()
        all += query(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
        all += query(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
        if (!onlyNew) return all
        val fresh = all.filter { it.path !in seen }
        fresh.forEach { seen.add(it.path) }
        return fresh
    }

    private fun query(ctx: Context, uri: Uri, video: Boolean): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        val proj = arrayOf(
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED
        )
        try {
            ctx.contentResolver.query(uri, proj, null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val iPath = c.getColumnIndexOrThrow(proj[0])
                val iName = c.getColumnIndexOrThrow(proj[1])
                val iSize = c.getColumnIndexOrThrow(proj[2])
                val iDate = c.getColumnIndexOrThrow(proj[3])
                while (c.moveToNext()) {
                    val p = c.getString(iPath) ?: continue
                    if (!File(p).exists()) continue
                    out.add(MediaItem(p, c.getString(iName) ?: File(p).name,
                        c.getLong(iSize), c.getLong(iDate), video))
                }
            }
        } catch (_: Exception) {}
        return out
    }

    fun folders(ctx: Context): Map<String, Int> {
        val m = LinkedHashMap<String, Int>()
        scan(ctx).forEach {
            val f = File(it.path).parentFile?.name ?: "?"
            m[f] = (m[f] ?: 0) + 1
        }
        return m
    }

    fun inFolder(ctx: Context, folder: String): List<MediaItem> =
        scan(ctx).filter { File(it.path).parentFile?.name == folder }
}